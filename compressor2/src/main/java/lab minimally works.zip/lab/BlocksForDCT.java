package lab;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static lab.byteReader.readBytes;

public class BlocksForDCT {
    public int width;
    public int height;
    public List<byte[]> blocks;

    BlocksForDCT(int w, int h, List<byte[]> b) {
        width = w;
        height = h;
        blocks = b;
    }

    BlocksForDCT() {
    }

    public void getBlocksForDCT(String filename) throws IOException {
        byte[] Text = readBytes(filename + ".raw");
        StringBuilder wid = new StringBuilder();
        StringBuilder hei = new StringBuilder();
        int skip = 0;
        while (Text[skip] != (byte) 'x' && skip < Text.length - 1) {
            wid.append((char) Text[skip]);
            skip++;
        }
        skip++;
        while (Text[skip] != (byte) 'Y' && Text[skip] != (byte) 'y' && Text[skip] != (byte) 'b' && skip < Text.length - 1) {
            hei.append((char) Text[skip]);
            skip++;
        }
        int w = width = Integer.parseInt(wid.toString());
        int h = height = Integer.parseInt(hei.toString());
        blocks = new ArrayList<>();
        byte[] block;
        int pixelPos;
        skip++;
        for (int i = 0; i < w * h / 64; i++) {    //мб + skip (или без)
            block = new byte[64];
            for (int j = 0; j < 64; j++) {
                pixelPos = skip + 3 * (8 * (i % (w / 8)) + 8 * w * (i / (w / 8)) + j % 8 + w * (j / 8));
                block[j] = Text[pixelPos];
            }
            blocks.add(block);
        }
    }

    public static byte[] fromBlocksToBytes(BlocksForDCT Blocks) { //когда в raw возвращать (перед YPlusCbCrToRaw?) //новая
        byte[] Y = new byte[Blocks.width * Blocks.height];
        int index = 0;
        for (int i = 0; i < Blocks.height; i++) {
            for (int j = 0; j < Blocks.width / 8; j++) {
                for (int k = 0; k < 8; k++) {
                    Y[index] = Blocks.blocks.get(i / 8 * Blocks.width / 8 + j)[(i % 8) * 8 + k]; //изменен добавил / 8 после i
                    index++;
                }
            }
        }
        return Y;
    }

    public static byte[] fromBadBlocksToBytes(BlocksForDCT Blocks) { //когда в raw возвращать (перед YPlusCbCrToRaw?) //новая
        byte[] Y = new byte[Blocks.width * Blocks.height];
        int w = Blocks.width;
        int h = Blocks.height;
        int index = 0;
        if (w % 8 != 0) {
            for (int i = 0; i < Blocks.height + h % 8; i++) {
                for (int j = 0; j < Blocks.width / 8 + 1; j++) {
                    if (j < w / 8) {
                        for (int k = 0; k < 8; k++) {
                            Y[index] = Blocks.blocks.get(i / 8 * Blocks.width / 8 + j)[(i % 8) * 8 + k]; //изменен добавил / 8 после i
                            index++;
                        }
                    } else {
                        for (int k = 0; k < w % 8; k++) {
                            Y[index] = Blocks.blocks.get(i / 8 * Blocks.width / 8 + j)[(i % 8) * 8 + k]; //изменен добавил / 8 после i
                            index++;
                        }
                    }
                }
            }
        } else {
            for (int i = 0; i < Blocks.height; i++) {
                for (int j = 0; j < Blocks.width / 8; j++) {
                    for (int k = 0; k < 8; k++) {
                        Y[index] = Blocks.blocks.get(i / 8 * Blocks.width / 8 + j)[(i % 8) * 8 + k]; //изменен добавил / 8 после i
                        index++;
                    }
                }
            }
        }
        return Y;
    }

    public void getBadBlocksForDCT(String filename) throws IOException {
        byte[] Text = readBytes(filename + ".raw");
        StringBuilder wid = new StringBuilder();
        StringBuilder hei = new StringBuilder();
        int skip = 0;
        while (Text[skip] != (byte) 'x' && skip < Text.length - 1) {
            wid.append((char) Text[skip]);
            skip++;
        }
        skip++;
        while (Text[skip] != (byte) 'Y' && Text[skip] != (byte) 'y' && Text[skip] != (byte) 'b' && skip < Text.length - 1) {
            hei.append((char) Text[skip]);
            skip++;
        }
        int w = width = Integer.parseInt(wid.toString());
        int h = height = Integer.parseInt(hei.toString());
        blocks = new ArrayList<>();
        byte[] block;
        int pixelPos;
        skip++;
        int avg;
        int numberOfOut;
        if (w % 8 != 0 && h % 8 != 0) {
            for (int i = 0; i < w * h / 64 + h / 8 + w / 8 + 1; i++) {    //мб + skip (или без)
                avg = 0;
                block = new byte[64];
                numberOfOut = 0;
                if ((i + 1) % (w / 8 + 1) == 0 && i + 1 >= (w * h / 64 + h / 8)) { //номер блока
                    for (int j = 0; j < 64; j++) {
                        if ((j + 1) % 8 > w % 8 || (j + 1) / 8 > h % 8) {
//индекс в блоке
                            numberOfOut++;
                            continue;
                        }
                        pixelPos = skip + 3 * (8 * (i % (w / 8)) + 8 * w * (i / (w / 8)) + j % 8 + w * (j / 8));
                        block[j] = Text[pixelPos];
                    }
                    for (int j = 0; j < 64; j++) { //поиск среднего
                        avg += block[j] & 0xFF;
                    }
                    avg /= (64 - numberOfOut);
                    for (int j = 0; j < 64; j++) {
                        if ((j + 1) % 8 > w % 8 || (j + 1) / 8 > h % 8) {
//индекс в блоке
                            block[j] = (byte) avg;
                        }
                    }
                } else if ((i + 1) % (w / 8 + 1) == 0) {
                    for (int j = 0; j < 64; j++) {
                        if ((j + 1) % 8 > w % 8) {
//индекс в блоке
                            numberOfOut++;
                            continue;
                        }
                        pixelPos = skip + 3 * (8 * (i % (w / 8)) + 8 * w * (i / (w / 8)) + j % 8 + w * (j / 8));
                        block[j] = Text[pixelPos];
                    }
                    for (int j = 0; j < 64; j++) { //поиск среднего
                        avg += block[j] & 0xFF;
                    }
                    avg /= (64 - numberOfOut);
                    for (int j = 0; j < 64; j++) {
                        if ((j + 1) % 8 > w % 8) {
//индекс в блоке
                            block[j] = (byte) avg;
                        }

                    }
                } else if (i + 1 >= (w * h / 64 + h / 8)) {
                    for (int j = 0; j < 64; j++) {
                        if ((j + 1) / 8 > h % 8) {
//индекс в блоке
                            numberOfOut++;
                            continue;
                        }
                        pixelPos = skip + 3 * (8 * (i % (w / 8)) + 8 * w * (i / (w / 8)) + j % 8 + w * (j / 8));
                        block[j] = Text[pixelPos];
                    }
                    for (int j = 0; j < 64; j++) { //поиск среднего
                        avg += block[j] & 0xFF;
                    }
                    avg /= (64 - numberOfOut);
                    for (int j = 0; j < 64; j++) {
                        if ((j + 1) / 8 > h % 8) {
//индекс в блоке
                            block[j] = (byte) avg;
                        }
                    }
                } else {  //added 26.05
                    for (int j = 0; j < 64; j++) {
                        pixelPos = skip + 3 * (8 * (i % (w / 8)) + 8 * w * (i / (w / 8)) + j % 8 + w * (j / 8));
                        block[j] = Text[pixelPos];
                    }
                }
                blocks.add(block);
            }
        } else if (w % 8 != 0) {
            for (int i = 0; i < w * h / 64 + h / 8; i++) {    //мб + skip (или без)
                avg = 0;
                block = new byte[64];
                numberOfOut = 0;
                if ((i + 1) % (w / 8 + 1) == 0) {
                    for (int j = 0; j < 64; j++) {
                        if ((j + 1) % 8 > w % 8) {
//индекс в блоке
                            numberOfOut++;
                            continue;
                        }
                        pixelPos = skip + 3 * (8 * (i % (w / 8)) + 8 * w * (i / (w / 8)) + j % 8 + w * (j / 8));
                        block[j] = Text[pixelPos];
                    }
                    for (int j = 0; j < 64; j++) { //поиск среднего
                        avg += block[j] & 0xFF;
                    }
                    avg /= (64 - numberOfOut);
                    for (int j = 0; j < 64; j++) {
                        if ((j + 1) % 8 > w % 8) {
//индекс в блоке
                            block[j] = (byte) avg;
                        }

                    }
                } else {  //added 26.05
                    for (int j = 0; j < 64; j++) {
                        pixelPos = skip + 3 * (8 * (i % (w / 8)) + 8 * w * (i / (w / 8)) + j % 8 + w * (j / 8));
                        block[j] = Text[pixelPos];
                    }
                }
                blocks.add(block);
            }
        } else if (h % 8 != 0) {
            for (int i = 0; i < w * h / 64 + h / 8 + w / 8 + 1; i++) {    //мб + skip (или без)
                avg = 0;
                block = new byte[64];
                numberOfOut = 0;
                if (i + 1 >= (w * h / 64 + h / 8)) {   //мб не хватает случая всего нижнего уровня
                    for (int j = 0; j < 64; j++) {
                        if ((j + 1) / 8 > h % 8) {
//индекс в блоке
                            numberOfOut++;
                            continue;
                        }
                        pixelPos = skip + 3 * (8 * (i % (w / 8)) + 8 * w * (i / (w / 8)) + j % 8 + w * (j / 8));
                        block[j] = Text[pixelPos];
                    }
                    for (int j = 0; j < 64; j++) { //поиск среднего
                        avg += block[j] & 0xFF;
                    }
                    avg /= (64 - numberOfOut);
                    for (int j = 0; j < 64; j++) {
                        if ((j + 1) / 8 > h % 8) {
//индекс в блоке
                            block[j] = (byte) avg;
                        }
                    }
                } else {  //added 26.05
                    for (int j = 0; j < 64; j++) {
                        pixelPos = skip + 3 * (8 * (i % (w / 8)) + 8 * w * (i / (w / 8)) + j % 8 + w * (j / 8));
                        block[j] = Text[pixelPos];
                    }
                }
                blocks.add(block);
            }
        } else {
            for (int i = 0; i < w * h / 64; i++) {    //мб + skip (или без)
                block = new byte[64];
                for (int j = 0; j < 64; j++) {
                    pixelPos = skip + 3 * (8 * (i % (w / 8)) + 8 * w * (i / (w / 8)) + j % 8 + w * (j / 8));
                    block[j] = Text[pixelPos];
                }
                blocks.add(block);
            }
        }
    }
}
