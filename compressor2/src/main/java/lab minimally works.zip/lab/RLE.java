package lab;

import java.util.ArrayList;
import java.util.List;

public class RLE {
    public static List<List<Integer>> AcRleE (List<int[]> ACs) {
        int Count = 0;
        List<List<Integer>> Encoded = new ArrayList<>();
        List<Integer> EncBlock;
        for (int[] Block : ACs) {
            EncBlock = new ArrayList<>();
            for (int i = 0; i < 63; i++) {
                while (i < 62 && Block[i] == 0 && Count < 15) { //изменен на 62
                    Count++;
                    i++;
                } //мб потом объединять F0 в 00
                if (Block[i] == 0) {
                    if (i == 62) { //изменен на 62
                        EncBlock.add(0);
                        EncBlock.add(0);
                    }
                    else {
                        EncBlock.add(Count);    //15
                        EncBlock.add(0);
                    }
                }
                else {
                    EncBlock.add(Count);
                    EncBlock.add(Block[i]);
                }
                Count = 0;
            }
            Encoded.add(EncBlock);
        }
        return Encoded;
    }

    public static List<int[]> AcRleD (List<List<Integer>> Encoded) {
        List<int[]> ACs = new ArrayList<>();
        int[] Block;
        int index;
        for (List<Integer> EncBlock : Encoded) {
            Block = new int[63];
            index = 0;
            for (int i = 0; i < EncBlock.size(); i += 2) {
                if (EncBlock.get(i) == 0 && EncBlock.get(i + 1) == 0) {
                    while (index <= 62) { //изменен на 62
                        Block[index] = 0;
                        index++;
                    }
                }
                else if (EncBlock.get(i) != 0) {
                    for (int j = EncBlock.get(i); j > 0; j--) {
                        Block[index] = 0;
                        index++;
                    }
                    Block[index] = EncBlock.get(i + 1);
                    index++;    //изм добавил итерацию
                }
                else {  //0 нулей
                    Block[index] = EncBlock.get(i + 1);
                    index++;
                }
            }
            ACs.add(Block);
        }
        return ACs;
    }

    public static void main (String[] args) {
        List<int[]> ACs = new ArrayList<>();
        int[] acBlock = {12,-18,6,-8,5,0,-7,11,-8,-1,-2,1,3,1,0,0,-2,3,-3,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1};
        ACs.add(acBlock);
        List<List<Integer>> ACEncoded = AcRleE(ACs);
        System.out.println("ACEncoded");
        for (int i = 0; i < ACEncoded.size(); i++) {
            for (int j = 0; j < ACEncoded.get(i).size(); j++) {
                System.out.println(ACEncoded.get(i).get(j));
            }
        }
        List<int[]> ACDecoded = AcRleD(ACEncoded);
        System.out.println("ACDecoded");
        for (int i = 0; i < ACEncoded.size(); i++) {
            for (int j = 0; j < 63; j++) {
                System.out.print(ACDecoded.get(i)[j]);
            }
        }
    }
}
