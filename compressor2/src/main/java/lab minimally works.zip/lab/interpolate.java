package lab;

public class interpolate {
    public static int interpolateLin(int x, int x1, int x2, int y1, int y2) { //x E (x1; x2)
        if (x2 > x1) {
            return ((x - x1) * y2 + (x2 - x) * y1)/(x2 - x1);
        } else {
            return ((x - x2) * y1 + (x1 - x) * y2)/(x1 - x2);
        }
    }

    public static int interpolateBilin(int x, int y, int x1, int x2, int y1, int y2, int z11, int z12, int z21, int z22) {
        return (((x - x1) * z12 + (x2 - x) * z11) / (x2 - x1) * (y2 - y) + ((x - x1) * z22 + (x2 - x) * z21) / (x2 - x1) * (y - y1)) / (y2 - y1);
    }
}