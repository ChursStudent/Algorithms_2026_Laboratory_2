package lab;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

import static lab.YCbCrConverter.Clamp;
import static lab.byteReader.readBytes;

public class downSample {
    public record Pair<File, CbCr>(File filenameWithY, CbCr cbcr) {
    }

    public static Pair<String,byte[]> downSampling(String filename) throws IOException {
        byte[] Text = readBytes(filename + ".raw");
        int i = 0;
        int j = 1;
        int avg;
        StringBuilder wid = new StringBuilder();
        while (Text[i] != (byte)'x' && i < Text.length - 1) {
            wid.append((char)Text[i]);
            i++;
        }
        int lineWidth = Integer.parseInt(wid.toString()) * 3;   //изменен везде width * 3
        while (Text[i] != 'Y' && Text[i] != 'y' && Text[i] != 'b') {
            i++;
        }
        byte[] CbCr = new byte[(Text.length - i - 1) / 6]; // мин массив для Cb Cr
        //System.out.println(CbCr.length);
        //int Continue = new Scanner(System.in).nextInt();
        int CbCrIndex = 0;
        int start = i += 2;
        for (; i + 3 + j * lineWidth < Text.length; i += 6) {   //без 0xFF всё становилось зелёным
            avg = Clamp(((Text[i + (j - 1) * lineWidth] & 0xFF)
                    + (Text[i + 3 + (j - 1) * lineWidth] & 0xFF)
                    + (Text[i + j * lineWidth] & 0xFF)
                    + (Text[i + 3 + j * lineWidth] & 0xFF)) / 4);
            Text[i + (j - 1) * lineWidth] = (byte)avg;
            Text[i + 3 + (j - 1) * lineWidth] = (byte)avg;
            Text[i + j * lineWidth] = (byte)avg;
            Text[i + 3 + j * lineWidth] = (byte)avg;
            if (i + 6 - start > lineWidth) {    //изменен добавил - start
                i -= lineWidth;
                j += 2;
            }

            CbCr[CbCrIndex] = (byte)avg;
            CbCrIndex += 2;
        }
        start++;
        i = start;
        j = 1; //добавил
        CbCrIndex = 1;
        for (; i + 3 + j * lineWidth < Text.length; i += 6) {
            avg = Clamp(((Text[i + (j - 1) * lineWidth] & 0xFF)
                    + (Text[i + 3 + (j - 1) * lineWidth] & 0xFF)
                    + (Text[i + j * lineWidth] & 0xFF)
                    + (Text[i + 3 + j * lineWidth] & 0xFF)) / 4);
            Text[i + (j - 1) * lineWidth] = (byte)avg;
            Text[i + 3 + (j - 1) * lineWidth] = (byte)avg;
            Text[i + j * lineWidth] = (byte)avg;
            Text[i + 3 + j * lineWidth] = (byte)avg;
            if (i + 6 - start > lineWidth) {    //изменен добавил - start
                i -= lineWidth;
                j += 2;
            }

            CbCr[CbCrIndex] = (byte)avg;
            CbCrIndex += 2;
        }
        /*
        System.out.println(CbCr[CbCr.length-2] & 0xFF);
        System.out.println(CbCr[CbCr.length-1] & 0xFF);
        int Continue2 = new Scanner(System.in).nextInt();
        */
        Files.write(Paths.get(filename + "DS.raw"), Text);
        return new Pair<>(filename + "DS", CbCr);
    }

    public static byte[] upSampling(byte[] CbCr, int origWidth, int origHeight) throws IOException {
        byte[] origCbCr = new byte[CbCr.length * 4];
        for (int i = 0; i < origHeight; i++){
            for (int j = 0; j < origWidth * 2; j+=2) {
                origCbCr[i * origWidth * 2 + j] = CbCr[((i - i % 2) / 2) * origWidth + ((j - j % 4) / 4) * 2];
                origCbCr[i * origWidth * 2 + j + 1] = CbCr[((i - i % 2) / 2) * origWidth + ((j - j % 4) / 4) * 2 + 1];
            }
        }
        /*
        int i = 0;
        int j = 1;
        for (; i + (j - 1) / 2 * origWidth / 3 < CbCr.length && j < origHeight; i += 2) { //изменено добавил j < origHeight
            origCbCr[i * 2 + (j - 1) * origWidth * 2 / 3] = CbCr[i + (j - 1) / 2 * origWidth / 3];    //изм везде origWid по другому
            origCbCr[i * 2 + 2 + (j - 1) * origWidth * 2 / 3] = CbCr[i + (j - 1) / 2 * origWidth / 3];
            origCbCr[i * 2 + j * origWidth * 2 / 3] = CbCr[i + (j - 1) / 2 * origWidth / 3];
            origCbCr[i * 2 + 2 + j * origWidth * 2 / 3] = CbCr[i + (j - 1) / 2 * origWidth / 3];
            origCbCr[i * 2 + (j - 1) * origWidth * 2 / 3 + 1] = CbCr[i + 1 + (j - 1) / 2 * origWidth / 3];
            origCbCr[i * 2 + 2 + (j - 1) * origWidth * 2 / 3 + 1] = CbCr[i + 1 + (j - 1) / 2 * origWidth / 3];
            origCbCr[i * 2 + j * origWidth * 2 / 3 + 1] = CbCr[i + 1 + (j - 1) / 2 * origWidth / 3];
            origCbCr[i * 2 + 2 + j * origWidth * 2 / 3 + 1] = CbCr[i + 1 + (j - 1) / 2 * origWidth / 3];
            if (i + 2 > origWidth / 3) {
                i -= origWidth / 3; //изменен добавил / 2
                j += 2;
            }
        }
        */
        return origCbCr;
    }
}
