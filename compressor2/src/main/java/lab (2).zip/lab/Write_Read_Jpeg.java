package lab;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import static lab.AnyBmpToRaw.BTR;
import static lab.AnyRawToBmp.RTB;
import static lab.BlocksForDCT.fromBlocksToBytes;
import static lab.CompileYBlocksAndCbCrChannels.YPlusCbCrToRaw;
import static lab.CompileYBlocksAndCbCrChannels.getCbCrFromEncoded;
import static lab.DCT.DctFaster;
import static lab.DCT.iDctFaster;
import static lab.Huffman.*;
import static lab.Quant.*;
import static lab.RLE.AcRleD;
import static lab.RLE.AcRleE;
import static lab.YCbCrConverter.fromYCbCr;
import static lab.YCbCrConverter.toYCbCr;
import static lab.byteReader.readBytes;
import static lab.diffEnc.DcDiffD;
import static lab.diffEnc.DcDiffE;
import static lab.downSample.downSampling;
import static lab.downSample.upSampling;
import static lab.getDC_AC.*;
import static lab.readMetaForYCbCr.readMetaYCC;
import static lab.varLenEnc.*;

public class Write_Read_Jpeg {
    public static String writeJpg () throws IOException {
        Scanner in = new Scanner(System.in);
        System.out.println("Введите имя bmp файла без расширения ");
        String FileName = in.nextLine();
        String RawFileName = BTR(FileName);
        String RawYCbCr = toYCbCr(RawFileName);

        byte[] Meta = readMetaYCC(RawYCbCr); //to write

        downSample.Pair<String, byte[]> DsResult = downSampling(RawYCbCr);
        String RawYCbCrDS = DsResult.filenameWithY();
        byte[] CbCr = DsResult.cbcr();  //to write
        for (int i = 0; i < CbCr.length; i++) {
            System.out.println(CbCr[i] & 0xFF);
        }
        RTB(fromYCbCr(RawYCbCrDS));

        BlocksForDCT Blocks = new BlocksForDCT();
        Blocks.getBlocksForDCT(RawYCbCrDS);
        List<int[]> BlocksDCTed = DctFaster(Blocks);

        for (int i = 0; i < BlocksDCTed.size(); i++) {
            for (int j = 0; j < 64; j++) {
                System.out.println(BlocksDCTed.get(i)[j] & 0xFF);
            }
        }

        Quant QMatrix = new Quant();
        System.out.println("Введите коэффициент качества от 1 до 99 (стандарт - 50) ");
        int Quality = in.nextInt();
        QMatrix.changeQuality(Quality);
        List<int[]> BlocksDCTedQed = Quantize(BlocksDCTed, QMatrix.QTable);
        byte[] QM = QMatrix.returnQMatrix(); //to write

        for (int i = 0; i < BlocksDCTedQed.size(); i++) {
            for (int j = 0; j < 64; j++) {
                System.out.println(BlocksDCTedQed.get(i)[j] & 0xFF);
            }
        }

        System.out.println("DCTed");

        int[] DCs = getDCs (BlocksDCTedQed);

        /*
        for (int j = 0; j < DCs.length; j++) {
            System.out.println(DCs[j] & 0xFF);
        }

         */
        List<int[]> ACs = getACs (BlocksDCTedQed);
/*
        for (int i = 0; i < ACs.size(); i++) {
            for (int j = 0; j < 63; j++) {
                System.out.println(ACs.get(i)[j] & 0xFF);
            }
        }
*/
        int[] diffEncoded = DcDiffE (DCs);
        List<List<Integer>> rleEncoded = AcRleE (ACs);

        System.out.println("diff-rle-ed");

        DCVarLen[] varDCs = DcVarLenE (diffEncoded);
        List<List<ACVarLen>> varACs = AcVarLenE (rleEncoded);

        System.out.println("var-ed");

        Huffman HTables = new Huffman();
        byte[] DcHuEncoded = DCHuE(varDCs, HTables.DCHuTable);  //to write

        System.out.println("DCHued");

        byte[] AcHuEncoded = ACHuE(varACs, HTables.ACHuTable);  //to write

        System.out.println("ACHued");

        byte[] DCHuT = HTables.returnDCHuTable();    //to write
        byte[] ACHuT = HTables.returnACHuTable();    //to write

        System.out.println("Hued");

        byte[] Result;
        if (Meta[Meta.length - 1] == 'Y') {
            Result = new byte[Meta.length + CbCr.length + QM.length + DCHuT.length + ACHuT.length + DcHuEncoded.length + AcHuEncoded.length];
            System.arraycopy(Meta, 0, Result, 0, Meta.length);
            System.arraycopy(CbCr, 0, Result, Meta.length, CbCr.length);
            System.arraycopy(QM, 0, Result, Meta.length + CbCr.length, QM.length);
            System.arraycopy(DCHuT, 0, Result, Meta.length + CbCr.length
                    + QM.length, DCHuT.length);
            System.arraycopy(ACHuT, 0, Result, Meta.length + CbCr.length
                    + QM.length + DCHuT.length, ACHuT.length);
            System.arraycopy(DcHuEncoded, 0, Result, Meta.length + CbCr.length
                    + QM.length + DCHuT.length + ACHuT.length, DcHuEncoded.length);
            System.arraycopy(AcHuEncoded, 0, Result, Meta.length + CbCr.length
                    + QM.length + DCHuT.length + ACHuT.length + DcHuEncoded.length, AcHuEncoded.length);
        }
        else {
            Result = new byte[Meta.length + QM.length + DCHuT.length + ACHuT.length + DcHuEncoded.length + AcHuEncoded.length];
            System.arraycopy(Meta, 0, Result, 0, Meta.length);
            System.arraycopy(QM, 0, Result, Meta.length, QM.length);
            System.arraycopy(DCHuT, 0, Result, Meta.length
                    + QM.length, DCHuT.length);
            System.arraycopy(ACHuT, 0, Result, Meta.length
                    + QM.length + DCHuT.length, ACHuT.length);
            System.arraycopy(DcHuEncoded, 0, Result, Meta.length
                    + QM.length + DCHuT.length + ACHuT.length, DcHuEncoded.length);
            System.arraycopy(AcHuEncoded, 0, Result, Meta.length
                    + QM.length + DCHuT.length + ACHuT.length + DcHuEncoded.length, AcHuEncoded.length);
        }
        Files.write(Paths.get(FileName + "JPEG.raw"), Result);
        return FileName + "JPEG";
    }

    public static String readJpg () throws IOException {    //вернет bmp
        Scanner in = new Scanner(System.in);
        System.out.println("Введите имя raw файла (jpeg) без расширения ");
        String FileName = in.nextLine();

        int currentPos;
        byte[] Meta = readMetaYCC(FileName);
        currentPos = Meta.length;

        int width;  //нахождение размеров изображения
        int height;
        int i = 0;
        StringBuilder wid = new StringBuilder();
        while (Meta[i] != 'x') {
            wid.append((char)(Meta[i] & 0xFF));
            i++;
        }
        i++;
        StringBuilder hei = new StringBuilder();
        while (Meta[i] != 'Y' && Meta[i] != 'y' && Meta[i] != 'b') {
            hei.append((char)(Meta[i] & 0xFF));
            i++;
        }
        width = Integer.parseInt(wid.toString());
        height = Integer.parseInt(hei.toString());

        byte[] CbCr = null;
        int CbCrLen = 0;
        if (Meta[Meta.length - 1] == 'Y') {
            CbCr = getCbCrFromEncoded(FileName, currentPos, width * height);
            CbCrLen = CbCr.length;
        }
        currentPos += CbCrLen;

        byte[] Text = readBytes(FileName + ".raw");
        int[] QM = readQMatrix(Text, currentPos);

        for (; currentPos < Text.length; currentPos++) {    //поиск конца QM / начала DCHuT
            if (Text[currentPos] == '.') {
                break;
            }
        }
        currentPos++;
        Map<Integer, String> DCHuT = readHuTable (Text, currentPos, 'D');

        for (; currentPos < Text.length; currentPos++) {
            if (Text[currentPos] == '.') {
                break;
            }
        }
        currentPos++;
        Map<Integer, String> ACHuT = readHuTable (Text, currentPos, 'A');

        for (; currentPos < Text.length; currentPos++) {
            if (Text[currentPos] == '.') {
                break;
            }
        }
        currentPos++;
        byte[] HuEncoded = new byte[Text.length - currentPos];
        System.arraycopy(Text, currentPos, HuEncoded, 0, HuEncoded.length);
        Pair <DCVarLen[], List<List<ACVarLen>>> HuDecoded = DcAcHuD(HuEncoded, width * height, DCHuT, ACHuT);

        int[] diffEncoded = DcVarLenD (HuDecoded.dcs());
        List<List<Integer>> rleEncoded = AcVarLenD (HuDecoded.acs());

        int[] DCs = DcDiffD (diffEncoded);
        List<int[]> ACs = AcRleD (rleEncoded);

        List<int[]> BlocksDCTedQed = putDcAc(DCs, ACs);

        List<int[]> BlocksDCTed = DeQuantize(BlocksDCTedQed, QM);

        BlocksForDCT Blocks = iDctFaster(BlocksDCTed, width, height);

        byte[] Y = fromBlocksToBytes (Blocks);

        byte[] origCbCr = null;
        if (CbCr != null) {
            origCbCr = upSampling(CbCr, width, height);
        }

        byte[] YCbCr = YPlusCbCrToRaw (Y, origCbCr, (char)(Meta[Meta.length - 1] & 0xFF));

        byte[] RawYCC = new byte[Meta.length + YCbCr.length];
        System.arraycopy(Meta, 0, RawYCC, 0, Meta.length);
        System.arraycopy(YCbCr, 0, RawYCC, Meta.length, YCbCr.length);
        Files.write(Paths.get(FileName + "Decompressed.raw"), RawYCC);
        String RawFileName = fromYCbCr(FileName + "Decompressed");
        RTB(RawFileName);
        return FileName + "DecompressedFromRaw";
    }
}
