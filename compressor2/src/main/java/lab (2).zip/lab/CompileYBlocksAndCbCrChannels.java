package lab;


import java.io.IOException;

import static lab.byteReader.readBytes;

public class CompileYBlocksAndCbCrChannels {
    public static byte[] getHuBytesFromEncoded(String filename) {
        return null;
    }

    public static byte[] getCbCrFromEncoded(String filename, int startIndex, int WidXHei) throws IOException {
        byte[] Result = new byte[WidXHei / 2];
        byte[] Text = readBytes(filename + ".raw");
        for (int i = startIndex; i < Result.length; i++) {
            Result[i] = Text[i];
        }
        return Result;
    }

    public static byte[] YPlusCbCrToRaw (byte[] Y, byte[] CbCr, char type) {   //новая
        byte[] Result = new byte[Y.length * 3];
        if (type == 'Y') {
            for (int i = 0; i < Result.length; i++) {
                if (i % 3 == 0) {
                    Result[i] = Y[i / 3];
                } else {
                    Result[i] = CbCr[i - i / 3 - 1];  //already upSampled
                }
            }
        }
        else {
            for (int i = 0; i < Result.length; i++) {
                Result[i] = Y[i / 3];
            }
        }
        return Result;
    }

    public static String CompileToRaw(String filename, BlocksForDCT Blocks, byte[] CbCr, char Color, int DS) {
        //запись width x height из Blocks
        //запись Color (Y, y или b)
        //перевод всех Block из Blocks в массив byte[]
        //поочередная запись из Y и DS*DS раз из CbCr (с прыжками)
        //запись в файл filename + "Recompiled.raw"
        return filename + "Recompiled";
    }
}
