package lab;

public class ZigArray {
    public static int[] toZig(int[] Array) {
        int[] Zig = new int[64];
        boolean up = true;
        boolean down = false;
        int indexX = 0;
        int indexY = 0;
        Zig[0] = Array[0];
        for (int i = 0; i < 63; i++) {
            if (up) {
                if (indexX + 1 < 8 && indexY - 1 >= 0) {
                    indexX++;
                    indexY--;
                }
                else {
                    up = false;
                    down = true;
                    if (indexX + 1 == 8) {  // x за пределами
                        indexY++;
                    }
                    else { // y за пределами
                        indexX++;
                    }
                }
            }
            else {
                if (indexX - 1 >= 0 && indexY + 1 < 8) {
                    indexX--;
                    indexY++;
                }
                else {
                    up = true;
                    down = false;
                    if (indexY + 1 == 8) {  // y за пределами
                        indexX++;
                    }
                    else { // x за пределами
                        indexY++;
                    }
                }
            }
            Zig[i + 1] = Array[8*indexY + indexX];
        }
        return Zig;
    }

    public static int[] fromZig(int[] Zig) {
        int[] Array = new int[64];
        boolean up = true;
        boolean down = false;
        int indexX = 0;
        int indexY = 0;
        Array[0] = Zig[0];
        for (int i = 0; i < 63; i++) {
            if (up) {
                if (indexX + 1 < 8 && indexY - 1 >= 0) {
                    indexX++;
                    indexY--;
                }
                else {
                    up = false;
                    down = true;
                    if (indexX + 1 == 8) {  // x за пределами
                        indexY++;
                    }
                    else { // y за пределами
                        indexX++;
                    }
                }
            }
            else {
                if (indexX - 1 >= 0 && indexY + 1 < 8) {
                    indexX--;
                    indexY++;
                }
                else {
                    up = true;
                    down = false;
                    if (indexY + 1 == 8) {  // y за пределами
                        indexX++;
                    }
                    else { // x за пределами
                        indexY++;
                    }
                }
            }
            Array[8*indexY + indexX] = Zig[i + 1];
        }
        return Array;
    }
}
